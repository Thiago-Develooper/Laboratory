//
//  AppleWatchTsssApp.swift
//  AppleWatchTsss Watch App
//
//  Created by Thiago Pereira de Menezes on 09/05/24.
//

import SwiftUI

@main
struct AppleWatchTsss_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
