//
//  AppleWatchTssApp.swift
//  AppleWatchTss
//
//  Created by Thiago Pereira de Menezes on 09/05/24.
//

import SwiftUI

@main
struct AppleWatchTssApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
